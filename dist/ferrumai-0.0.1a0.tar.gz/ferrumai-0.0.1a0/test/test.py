import ferrumai

def gsheet_test():
    url = "https://docs.google.com/spreadsheets/d/1lgeGSWQjJTNSgA3cjDAKmrPpeuvtjm3TF1RuTaDIcdo/edit?usp=sharing"
    df = ferrumai.ghsheet.