# FerrumAI
Step towards simplicity